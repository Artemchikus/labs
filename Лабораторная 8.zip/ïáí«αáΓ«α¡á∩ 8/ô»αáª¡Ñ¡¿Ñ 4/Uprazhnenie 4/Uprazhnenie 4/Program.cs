﻿using System;

namespace Uprazhnenie_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Какой тип прогрессии выбираешь? Арифм(1)/Геом(2)");
            string a = Console.ReadLine();
            if (int.Parse(a) == 1)
            {
                Console.WriteLine("Теперь вводи коэфицент(а не фигню всякую) B1 уравнения Bn=B1+d*(n-1)");
                double B1 = double.Parse(Console.ReadLine());
                Console.WriteLine("Теперь вводи коэфицент(а не фигню всякую) d уравнения Bn=B1+d*(n-1)");
                double d = double.Parse(Console.ReadLine());
                ArithmeticProgession arithmetic = new ArithmeticProgession(B1, d);
                Console.WriteLine("Теперь вводи коэфицент(а не фигню всякую) n уравнения Bn=B1+d*(n-1)");
                int n = int.Parse(Console.ReadLine());
                Console.WriteLine("Элемент на {0} месте равен {1}", n, arithmetic.GetElement(n));
            }
            else if (int.Parse(a) == 2)
            {
                Console.WriteLine("Теперь вводи коэфицент(а не фигню всякую) B1 уравнения Bn=B1*q^(n-1)");
                double B1 = double.Parse(Console.ReadLine());
                Console.WriteLine("Теперь вводи коэфицент(а не фигню всякую) q уравнения Bn=B1*q^(n-1)");
                double q = double.Parse(Console.ReadLine());
                GeometricProgression geometric = new GeometricProgression(B1, q);
                Console.WriteLine("Теперь вводи коэфицент(а не фигню всякую) n уравнения Bn=B1*q^(n-1)");
                int n = int.Parse(Console.ReadLine());
                Console.WriteLine("Элемент на {0} месте равен {1}", n, geometric.GetElement(n));
            }
        }
    }
}
