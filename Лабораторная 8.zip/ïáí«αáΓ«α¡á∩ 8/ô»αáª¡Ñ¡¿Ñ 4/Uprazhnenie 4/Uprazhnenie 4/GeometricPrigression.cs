﻿using System;

namespace Uprazhnenie_4
{
    public class GeometricProgression:IProgression
    {
        private double b1;
        private double q;
        public GeometricProgression(double b1, double q)
        {
            this.b1 = b1;
            this.q = q;
        }
        public double GetElement(int k)
        {
            return b1 * Math.Pow(q, k - 1);
        }
    }
}