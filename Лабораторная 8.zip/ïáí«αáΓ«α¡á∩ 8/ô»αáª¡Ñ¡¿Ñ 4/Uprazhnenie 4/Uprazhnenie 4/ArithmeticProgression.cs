﻿namespace Uprazhnenie_4
{
    public class ArithmeticProgession:IProgression
    {
        private double b1;
        private double d;

        public ArithmeticProgession(double b1, double d)
        {
            this.b1 = b1;
            this.d = d;
        }

        public double GetElement(int k)
        {
            return b1 + d * (k - 1);
        }
    }
}