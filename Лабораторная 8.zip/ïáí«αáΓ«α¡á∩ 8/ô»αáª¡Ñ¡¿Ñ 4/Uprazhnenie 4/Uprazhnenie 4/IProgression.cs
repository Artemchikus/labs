﻿namespace Uprazhnenie_4
{
    public interface IProgression
    {
        double GetElement(int k);

    }
}