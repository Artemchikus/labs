﻿using System;
using System.Collections.Generic;
using Uorazhnenie_1;

namespace MyClass
{
    class Book : Item, Ipr
    {
        public string Autor { get; set; }
        public string Title { get; set; }
        public Publisher Publ { get; set; }
        public int Pages { get; set; }
        public int Year { get; set; }
        public bool returnSrok { get; private set; }

        private static double price;

        public static double Price
        {
            get { return price; }
            set
            {
                if (value > 9)
                {
                    price = value;
                }
            }
        }

        public void setBook(string Autor, string Title, Publisher publisher, int Pages, int Year)
        {
            this.Autor = Autor;
            this.Pages = Pages;
            this.Publ = publisher;
            this.Title = Title;
            this.Year = Year;
        }

        public void SetPrice(double price)
        {
            Book.Price = price;
        }

        public override string ToString()
        {
            string bs = String.Format(
                "\nКнига: \nАвтор: {0}\nНазвание: {1}\nГод издания: {2}\n{3} стр.\nСтоимость аренды: {4} \nИздательство{5}", Autor, Title,
                Year, Pages, Price, Publ);
            return bs;
        }

        public override void Print()
        {
            Console.WriteLine(this);
            base.Print();
        }

        public double PriceBook(int s)
        {
            double cust = s * price;
            return cust;
        }

        public Book(string Autor, string Title, Publisher publisher, int Pages, int Year)
        {
            this.Autor = Autor;
            this.Pages = Pages;
            this.Publ = publisher;
            this.Title = Title;
            this.Year = Year;
        }
        public Book() { }

        static Book()
        {
            price = 9;
        }

        public Book(string Autor, string Title)
        {
            this.Autor = Autor;
            this.Title = Title;
        }
        public Book(string Autor, string Title, Publisher publisher, int Pages, int Year, long invNumber, bool taken) : base(invNumber, taken)
        {
            this.Autor = Autor;
            this.Pages = Pages;
            this.Publ = publisher;
            this.Title = Title;
            this.Year = Year;
        }

        public void ReturnSrok()
        {
            returnSrok = true;
        }

        public override void Return()
        {
            if (returnSrok == true)
            {
                taken = true;
            }
            else
            {
                taken = false;
            }
        }

        static void Main(string[] args)
        {
            Publisher publ = new Publisher(1234, new DateTime(2014, 12, 14), "Наука и жизнь", "nauka@mail.ru");


            Book b2 = new Book("Толстой Л.Н.", "Война и Мир", publ, 1234, 2013, 101, true);

            b2.TakeItem();
            b2.Print();

            Book b3 = new Book("Лермонтов М.Ю", "Мцыри");

            b3.Print();

            Magazine mag1 = new Magazine("О природе", 5, "Земля и мы", 2014, 1235, true);
            mag1.TakeItem();
            mag1.Print();
            mag1.Subs();
            mag1.Print();

            Console.WriteLine("\nТестирование полиморфизма");
            b2.ReturnSrok();
            Item it;
            it = b2;
            it.TakeItem();
            it.Return();
            it.Print();

            it = mag1;
            it.TakeItem();
            it.Return();
            it.Print();

            List<Item> itlList = new List<Item>();
            itlList.AddRange(new Item[]{b2,b3,mag1});
            itlList.Sort();
            Console.WriteLine("\n Сортировка по тнвертароному номеру");
            foreach (Item x in itlList)
            {
                x.Print();
            }
        }
    }
}
