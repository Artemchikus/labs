﻿namespace Uorazhnenie_1
{
    public interface Ipr
    {
        void SetPrice(double price);
        double PriceBook(int k);
    }
}