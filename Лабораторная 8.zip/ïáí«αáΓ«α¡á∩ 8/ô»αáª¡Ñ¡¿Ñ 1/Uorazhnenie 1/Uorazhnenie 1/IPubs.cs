﻿namespace Uorazhnenie_1
{
    public interface IPubs
    {
        void Subs();
        bool IfSubs { get; set; }

    }
}