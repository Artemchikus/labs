﻿using System;

namespace Uprazhnenie_4
{
    public class Operation
    {
        public static float Ploshad(float a, float b, float c)
        {
            float s = 0;
            bool ok = Operation.Est(a, b, c);
            if (ok)
            {
                float p = (a + b + c) / 2;
                s = (float)Math.Sqrt(p * (p - a) * (p - b) * (p - c));
                return s;
            }
            else
            {
                Console.WriteLine("Takogo treugolnika ne sushestvuet");
                return s
                    ;
            }
        }

        private static bool Est(float a, float b, float c)
        {
            bool ok;
            if (a<c+b && c<a+b && b<c+a)
            {
                ok = true;
            }
            else
            {
                ok = false;
            }
            return ok;
        }

        public static float Ravnostor(float a)
        {
            float p = a * 3 / 2;
            float s =(float)Math.Sqrt(p * Math.Pow(p - a, 3));
            return s;
        }
    }
}