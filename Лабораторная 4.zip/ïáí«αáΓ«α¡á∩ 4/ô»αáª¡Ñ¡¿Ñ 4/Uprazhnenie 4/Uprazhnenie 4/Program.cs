﻿using System;

namespace Uprazhnenie_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Tip treugolnika:\n Ravnostoronniy - 1\n Raznostoronniy - 2");
            string tip = Console.ReadLine();
            if (tip=="1")
            {
                Console.WriteLine("Vvedite dlinu storoni:");
                float a = float.Parse(Console.ReadLine());
                float s = Operation.Ravnostor(a);
                Console.WriteLine("Ploshad = "+s);
            }
            else if (tip=="2")
            {
                Console.WriteLine("Vvedite dlinu storoni 1:");
                float a = float.Parse(Console.ReadLine());
                Console.WriteLine("Vvedite dlinu storoni 2:");
                float b = float.Parse(Console.ReadLine());
                Console.WriteLine("Vvedite dlinu storoni 3:");
                float c = float.Parse(Console.ReadLine());
                float s = Operation.Ploshad(a, b, c);
                Console.WriteLine("Ploshad = "+s);
            }
            else
            {
                Console.WriteLine("Nepravilniy vvod");
            }
        }
    }
}
