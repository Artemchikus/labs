﻿using System;

namespace Utils
{
    class Program
    {
        static void Main(string[] args)
        {
            int x, y;
            Console.WriteLine("Vvvedite pervoe chislo");
            x = int.Parse(Console.ReadLine());
            Console.WriteLine("Vvedite vtoroe chislo");
            y = int.Parse(Console.ReadLine());
            int greater = Utils.Greater(x, y);
            Console.WriteLine("Bolshim iz chisel {0} i {1} yavlyaetsya {2}",x,y,greater);
            Console.WriteLine("Do swap: \t"+x+" "+y);
            Utils.Swap(ref x,ref y);
            Console.WriteLine("Posle swap: \t"+x+" "+y);
            bool ok;
            int f;
            Console.WriteLine("Number for factorial:");
            x = int.Parse(Console.ReadLine());
            ok = Utils.Factorial(x, out f);
            if (ok)
            {
                Console.WriteLine("Factorial("+x+") = "+f);
            }
            else
            {
                Console.WriteLine("Cannot compute this factorial");
            }
        }
    }
}
