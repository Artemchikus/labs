﻿using System;

namespace Uprazhnenie_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vvedite coeficent a:");
            float a = float.Parse(Console.ReadLine());
            Console.WriteLine("Vvedite coeficent b:");
            float b = float.Parse(Console.ReadLine());
            Console.WriteLine("Vvedite coeficent c:");
            float c = float.Parse(Console.ReadLine());
            float x1=0, x2=0;
            int i = Korni.Reshenie(a, b, c, ref x1, ref x2);
            if (i==1)
            {
                Console.WriteLine("Korni uravneniya s koeficentami a = {0}, b = {1}, c = {2} ravni x1 = {3}, x2 = {4}",a,b,c,x1,x2);
            }
            else if (i==0)
            {
                Console.WriteLine("Koren uravneniya s koeficentami a = {0}, b = {1}, c = {2} raven x1= {3}",a,b,c,x1);
            }
            else
            {
                Console.WriteLine("Korney uravneniya s koeficentami a = {0}, b = {1}, c = {2} net",a,b,c);
            }
        }
    }
}
