﻿using System;
using System.Text.RegularExpressions;

namespace Uprazhnenie_5
{
    public class Korni
    {
        public static int Reshenie(float a, float b, float c, ref float x1, ref float x2)
        {
            float d = b * b - 4 * a * c;
            if (d>0 && a>0)
            {
                x1 = (float) ((-b + Math.Sqrt(d)) / 2);
                x2 = (float)((-b - Math.Sqrt(d)) / 2);
                return 1;
            }
            else if (d==0)
            {
                x1 = (float)(-b/ 2);
                return 0;
            }
            else
            {
                return -1;
            }
        }
    }
}