﻿using System;

namespace MatrixMultiply
{
    class MatrixMultiply
    {
        static void Main(string[] args)
        {
            int[,] a = new int[2, 2];
            Input(a);

            int[,] b = new int[2, 2];
            Input(b);

            int[,] rezult = Multiply(a, b);
            Output(rezult);
        }

        private static void Input(int[,] a)
        {
            for (int i = 0; i < a.GetLength(0); i++)
            {
                for (int j = 0; j < a.GetLength(1); j++)
                {
                    Console.WriteLine("Enter value for [{0}, {1}] : ",i,j);
                    a[i, j] = int.Parse(Console.ReadLine());
                }
            }
        }

        private static int[,] Multiply(int[,] a, int[,] b)
        {
            int[,] rezult = new int[2, 2];
            for (int i = 0; i < rezult.GetLength(0); i++)
            {
                for (int j = 0; j < rezult.GetLength(1); j++)
                {
                    rezult[i, j] = a[i, 0] * b[0, j] + a[i, 1] * b[1, j];
                }
            }
            return rezult;
        }

        private static void Output(int[,] rezult)
        {
            for (int i = 0; i < rezult.GetLength(0); i++)
            {
                for (int j = 0; j < rezult.GetLength(1); j++)
                {
                    Console.Write(rezult[i, j] + " ");
                }

                Console.WriteLine();
            }
        }
    }
}
