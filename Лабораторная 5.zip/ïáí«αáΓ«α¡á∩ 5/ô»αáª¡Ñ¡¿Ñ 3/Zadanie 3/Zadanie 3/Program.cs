﻿using System;

namespace Zadanie_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Vvedite dlinu massiva\nn = ");
            int n = int.Parse(Console.ReadLine());

            int[] mas = new int[n];
            
            for (int i = 0; i < mas.Length; i++)
            {
                Console.Write("Vvedite mas[{0}] : ",i);
                mas[i] = int.Parse(Console.ReadLine());
            }

            Summa(mas);

            Sr_znach(mas);

            Summa_polozh_i_otrits(mas);

            Summa_chet_i_nechet(mas);

            Index_min_i_max(mas);

            Proizvedenie(mas);
        }

        private static void Proizvedenie(int[] mas)
        {
            int s = 0;
            int m = mas[0];
            for (int i = 0; i < mas.Length; i++)
            {
                if (mas[i] > s)
                {
                    s = i;
                }

                if (mas[i] < m)
                {
                    m = i;
                }
            }

            int g = 1;
            if (m > s)
            {
                for (int i = s + 1; i < m; i++)
                {
                    g *= mas[i];
                }
            }
            if (s > m)
            {
                for (int i = m + 1; i < s; i++)
                {
                    g *= mas[i];
                }
            }
            else
            {
                g = 0;
            }

            Console.WriteLine("Proizvedenie elementov mezhdu max i min = {0}", g);
        }

        private static void Index_min_i_max(int[] mas)
        {
            int s = 0;
            int m = mas[0];
            int g=0;
            int v=0;
            for (int i = 0; i < mas.Length; i++)
            {
                if (mas[i] > s)
                {
                    v = i;
                    s = mas[i];
                }

                if (mas[i] < m)
                {
                    g = i;
                    m = mas[i];
                }
            }

            Console.WriteLine("Index max elementa = {0}\nIndex min elementa = {1}", v, g);
        }

        private static void Summa_chet_i_nechet(int[] mas)
        {
            int s = 0;
            int m = 0;
            for (int i = 0; i < mas.Length; i++)
            {
                if (i % 2 == 0)
                {
                    s += mas[i];
                }
                else
                {
                    m += mas[i];
                }
            }

            Console.WriteLine("Summa elementov s chetnimy nomerami = {0}\nSumma elementov s hechetnimy nomerami= {1}", s, m);
        }

        private static void Summa_polozh_i_otrits(int[] mas)
        {
            int s = 0;
            int m = 0;
            for (int i = 0; i < mas.Length; i++)
            {
                if (mas[i] > 0)
                {
                    s += mas[i];
                }
                else
                {
                    m += mas[i];
                }
            }

            Console.WriteLine("Summa polozhitelnih elementov = {0}\nSumma otritsatelnih elementov = {1}", s, m);
        }

        private static void Sr_znach(int[] mas)
        {
            int s = 0;
            for (int i = 0; i < mas.Length; i++)
            {
                s += mas[i];
            }

            Console.WriteLine("Srednee znachenie elementov massiva = {0}", s / mas.Length);
        }

        private static void Summa(int[] mas)
        {
            int s = 0;
            for (int i = 0; i < mas.Length; i++)
            {
                s += mas[i];
            }

            Console.WriteLine("Summa elementov massiva = {0}", s);
        }
    }
}
