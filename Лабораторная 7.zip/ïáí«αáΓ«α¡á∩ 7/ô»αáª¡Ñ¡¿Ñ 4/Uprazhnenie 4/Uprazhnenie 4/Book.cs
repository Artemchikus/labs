﻿using System;

namespace MyClass
{
    class Book : Item
    {
        public string Autor { get; set; }
        public string Title { get; set; }
        public string Publisher { get; set; }
        public int Pages { get; set; }
        public int Year { get; set; }
        public bool returnSrok { get; private set; }

        private static double price;

        public static double Price
        {
            get { return price; }
            set
            {
                if (value > 9)
                {
                    price = value;
                }
            }
        }

        public void setBook(string Autor, string Title, string Publisher, int Pages, int Year)
        {
            this.Autor = Autor;
            this.Pages = Pages;
            this.Publisher = Publisher;
            this.Title = Title;
            this.Year = Year;
        }

        public static void setPrice(double price)
        {
            Book.Price = price;
        }

        public override string ToString()
        {
            string bs = String.Format(
                "\nКнига: \nАвтор: {0}\nНазвание: {1}\nГод издания: {2}\n{3} стр.\nСтоимость аренды: {4}", Autor, Title,
                Year, Pages, Price);
            return bs;
        }

        public override void Print()
        {
            Console.WriteLine(this);
            base.Print();
        }

        public double PriceBook(int s)
        {
            double cust = s * price;
            return cust;
        }

        public Book(string Autor, string Title, string Publisher, int Pages, int Year)
        {
            this.Autor = Autor;
            this.Pages = Pages;
            this.Publisher = Publisher;
            this.Title = Title;
            this.Year = Year;
        }
        public Book() { }

        static Book()
        {
            price = 9;
        }

        public Book(string Autor, string Title)
        {
            this.Autor = Autor;
            this.Title = Title;
        }
        public Book(string Autor, string Title, string Publisher, int Pages, int Year, long invNumber, bool taken) : base(invNumber, taken)
        {
            this.Autor = Autor;
            this.Pages = Pages;
            this.Publisher = Publisher;
            this.Title = Title;
            this.Year = Year;
        }

        public void ReturnSrok()
        {
            returnSrok = true;
        }

        public override void Return()
        {
            if (returnSrok == true)
            {
                taken = true;
            }
            else
            {
                taken = false;
            }
        }

        static void Main(string[] args)
        {
            Book b1 = new Book();
            b1.setBook("Пушкин А.С.", "Капитанская дочка", "Вильямс", 123, 2018);
            Book.setPrice(10);

            b1.Print();
            Console.WriteLine("\nИтоговая стоимость аренды: {0} р.", b1.PriceBook(3));

            Book b2 = new Book("Толстой Л.Н.", "Война и Мир", "Наука и Жизнь", 1234, 2013, 101, true);

            b2.TakeItem();
            b2.Print();

            Book b3 = new Book("Лермонтов М.Ю", "Мцыри");

            b3.Print();

            Magazine mag1 = new Magazine("О природе", 5, "Земля и мы", 2014, 1235, true);
            mag1.TakeItem();
            mag1.Print();

            Console.WriteLine("\nТестирование полиморфизма");
            b2.ReturnSrok();
            Item it;
            it = b2;
            it.TakeItem();
            it.Return();
            it.Print();

            it = mag1;
            it.TakeItem();
            it.Return();
            it.Print();
        }
    }
}