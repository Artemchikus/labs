﻿using System;

namespace MyClass
{
    public class Publisher
    {
        struct LicenseNumber
        {
            public int licenseNumber;
            public DateTime data;
            public override string ToString()
            {
                string bs=String.Format("Лицензия №-{0} от {1} г",licenseNumber,data);
                return bs;
            }
        }
        public string Name { get; set; }
        public string EmailAdress { get; set; }
        private LicenseNumber linNumber;

        public Publisher(int licenseNumber, DateTime data, string Name, string EmailAdress)
        {
            this.EmailAdress = EmailAdress;
            this.Name = Name;
            linNumber.licenseNumber = licenseNumber;
            linNumber.data = data;
        }

        public override string ToString()
        {
            string bs=String.Format(": {0}, электронный адрес: {1}, {2}",Name,EmailAdress,linNumber);
            return bs;
        }
    }
}