﻿using System;

namespace MyClass
{
    public class Item
    {
        protected long invNumber;
        protected bool taken;

        public bool IsAvailable()
        {
            if (taken == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public long getInvNumber()
        {
            return invNumber;
        }

        public void Take()
        {
            taken = true;
        }

        public void Return()
        {
            taken = false;
        }

        public void Print()
        {
            Console.WriteLine("\nСостояние единицы хранения: \nИнфертарный номер: {0} \nНалиие: {1}",invNumber,taken);
        }

    }
}
