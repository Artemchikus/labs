﻿using System;

namespace MyClass
{
    public class Magazine : Item
    {
        public string Volume { get; set; }
        public int Number { get; set; }
        public string Title { get; set; }
        public int Year { get; set; }

        public Magazine(string Volume, int Number, string Title, int Year, long invNumber, bool taken) : base(invNumber, taken)
        {
            this.Number = Number;
            this.Title = Title;
            this.Volume = Volume;
            this.Year = Year;
        }

        public Magazine()
        {

        }

        public override string ToString()
        {
            string bs = String.Format("\nЖурнал: \nТом: {0} \nНомер: {1} \nНазвание: {2} \nГод выпуска: {3}", Volume,
                Number, Title, Year);
            return bs;
        }

        public override void Print()
        {
            Console.WriteLine(this);
            base.Print();
        }

        public override void Return()
        {
            taken = true;
        }
    }
}