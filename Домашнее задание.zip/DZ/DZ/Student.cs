﻿using System;

namespace DZ
{
    public class Student: Person
    {
        private string tip = "student";
        public string facultet { set; get; }

        public string gruppa { set; get; }

        public Student(string facultet, string gruppa, string familiya, int god, int mesyaz, int den) : base(familiya, god, mesyaz, den)
        {
            this.facultet = facultet;
            this.gruppa = gruppa;
        }
        override public string GetTip()
        {
            return "student";
        }
        public override string ToString()
        {
            return base.ToString() + "\nФакультет: " + facultet + "\nГруппа: " + gruppa;
        }
    }
}