﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualBasic;

namespace DZ
{
    public abstract class Person
    {
        public string familiya { set; get; }
        public DateTime data_rozhdeniya { set; get; }
        public int vozrast { set; get; }

        public Person(string familiya, int god, int mesyaz, int den)
        {
            this.familiya = familiya;
            data_rozhdeniya = Data(god, mesyaz, den); ;
            int now = int.Parse(DateTime.Now.ToString("yyyyMMdd"));
            int dob = int.Parse(data_rozhdeniya.ToString("yyyyMMdd")); 
            vozrast = (now - dob) / 10000;
        }

        abstract public string GetTip();
        static public DateTime Data(int god, int mesyaz, int den)
        {
            DateTime dateTime = new DateTime(god, mesyaz, den);
            return dateTime;
        }

        public override string ToString()
        {
            return "\nФамилия: " + familiya + "\nДата рождения: " + data_rozhdeniya.ToShortDateString() + "\nВозраст: " + vozrast + "лет";
        }
    }
}