﻿using System;

namespace DZ
{
    public class Manager: Person, IEmployee
    {
        private string tip = "manager";
        public string dolzhnost { set; get; }

        public string facultet { set; get; }

        public int zarplata = 35000;

        public int Zarplata
        {
            set { zarplata = value; }
            get { return zarplata; }
        }

        public Manager(string dolzhnost, string facultet, string familiya, int god, int mesyaz, int den) :base(familiya, god, mesyaz, den)
        {
            this.dolzhnost = dolzhnost;
            this.facultet = facultet;
        }

        override public string GetTip()
        {
            return "manager";
        }
        public void RedZarplata(int zarp)
        {
            Zarplata = zarplata;
        }
        public override string ToString()
        {
            return base.ToString() + "\nДолжность: " + dolzhnost + "\nФакультет: " + facultet + "\nЗарплата: " + Zarplata;
        }
    }
}