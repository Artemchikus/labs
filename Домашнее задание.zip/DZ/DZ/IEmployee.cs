﻿using System;
using Microsoft.VisualBasic;

namespace DZ
{
    public interface IEmployee
    {
        public string dolzhnost { get; set; } 
        public string facultet { get; set; }
        public int Zarplata { get; set; }
        public void RedZarplata(int zarp);
    }
}