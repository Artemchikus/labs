﻿using System;

namespace DZ
{
    public class Admin: Person
    {
        public int lab { get; set; }

        public int zarplata = 32000;
        public int Zarplata
        {
            get { return zarplata; }
            set { zarplata = value; }
        }
        public Admin(int lab, int god, int mesyaz, int den, string familiya) :
            base(familiya, god, mesyaz, den)
        {
            this.lab = lab;
        }
        public void RedZarplata(int zarp)
        {
            Zarplata = zarplata;
        }
        override public string GetTip()
        {
            return "admin";
        }
        public override string ToString()
        {
            return base.ToString() + "\nЛаборатория: " + lab + "\nЗарплата: " + Zarplata;
        }
    }
}