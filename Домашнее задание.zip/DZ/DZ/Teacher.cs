﻿using System;

namespace DZ
{
    public class Teacher: Person, IEmployee
    {
        private string tip = "teacher";
        public string dolzhnost { get; set; }
        public string facultet { get; set; }
        public DateTime data_nachala_raboty { get; set; }
        public int stazh { set; get; }

        public int zarplata = 40000;
        public int Zarplata
        {
            get { return zarplata; }
            set { zarplata = value; }
        }

        public Teacher(string dolzhnost, string facultet, int god1, int mesyaz1, int den1, int god, int mesyaz, int den, string familiya) :
            base(familiya, god, mesyaz, den)
        {
            this.dolzhnost = dolzhnost;
            this.facultet = facultet;
            data_nachala_raboty = Data(god1, mesyaz1, den1);
            int now = int.Parse(DateTime.Now.ToString("yyyyMMdd"));
            int dob = int.Parse(data_nachala_raboty.ToString("yyyyMMdd"));
            stazh = (now - dob) / 10000;
        }
        override public string GetTip()
        {
            return "teacher";
        }
        public void RedZarplata(int zarp)
        {
            Zarplata = zarplata;
        }
        public override string ToString()
        {
            return base.ToString() + "\nДолжность: " + dolzhnost + "\nФакультет: " + facultet + "\nСтаж: " + stazh + " лет" + "\nЗарплата: " + Zarplata;
        }
    }
}