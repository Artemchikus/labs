﻿using System;
using System.Collections.Generic;
using DZ;

namespace Prilozhenie
{
    class Program
    {
        static int Obshenie1()
        { 
            Console.WriteLine("\nЧто делать?" +
                            "\n1 - Сортировка по Фамиллии." +
                            "\n2 - Сортировка по Дате рождения." +
                            "\n3 - Вывести что-то особенное." +
                            "\n4 - Конец.");
            int a = int.Parse(Console.ReadLine());
            if (a==3)
            {
                return Obshenie2();
            } 
            return a;
        }

        static int Obshenie2()
        {
            Console.WriteLine("\nЧто именно?" +
                              "\n1 - Только учителей." +
                              "\n2 - Только администраторов." +
                              "\n3 - Только менеджеров." +
                              "\n4 - Только студентов." +
                              "\n5 - Только работников." +
                              "\n6 - Людей в дипапазоне возраста.");
            int a = int.Parse(Console.ReadLine());
            return a*10;
        }
        static void Main(string[] args)
        {
            var collection = Collection();
            int vibor = 0;
            while (true)
            {
                if (vibor == 4)
                {
                    break;
                }
                vibor = Obshenie1();
                if (vibor<3)
                {
                    Sortir(ref collection, vibor);
                    foreach (Person a in collection)
                    {
                        Console.WriteLine(a.ToString());
                    }
                }

                if (vibor>=10)
                {
                    var otvet = Viborka(collection, ref vibor);
                    if (vibor!=4)
                    {
                        foreach (Person a in otvet)
                        {
                            Console.WriteLine(a.ToString());
                        }
                    }
                }
            }
        }

        private static List<Person> Collection()
        {
            Admin admin1 = new Admin(1, 2001, 1, 1, "Админ1");
            Admin admin2 = new Admin(2, 2002, 2, 2, "Админ2");
            Teacher teacher1 = new Teacher("страший учитель", "ИКТ", 2007, 3, 3, 2003, 4, 4, "Учитель1");
            Teacher teacher2 = new Teacher("младший учитель", "ПИИКТ", 2008, 5, 5, 2004, 6, 6, "Учитель2");
            Student student1 = new Student("ФБР", "K3121", "Студент1", 2005, 7, 7);
            Student student2 = new Student("ФСБ", "P3121", "Студент2", 2006, 8, 8);
            Manager manager1 = new Manager("страший менеджер", "ЦРУ", "Менеджер1", 2000, 9, 9);
            Manager manager2 = new Manager("младший менеджер", "КГБ", "Менеджер2", 1999, 10, 10);
            var collection = new List<Person>();
            collection.Add(admin1);
            collection.Add(admin2);
            collection.Add(teacher1);
            collection.Add(teacher2);
            collection.Add(student1);
            collection.Add(student2);
            collection.Add(manager1);
            collection.Add(manager2);
            return collection;
        }
        static public void Sortir(ref List<Person> list, int tip)
        {
            if (tip == 1)
            {
                list.Sort((a, b) => String.Compare(a.familiya, b.familiya));
            }

            if (tip == 2)
            {
                list.Sort((a,b)=> a.vozrast<b.vozrast ? 1:-1);
            }
        }

        static public List<Person> Viborka(List<Person> list, ref int tip)
        {
            List<Person> persons=new List<Person>();
            if (tip==10)
            {
                foreach (Person person in list)
                {
                    if (person.GetTip()=="teacher")
                    {
                        persons.Add(person);
                    }
                }
                return persons;
            }

            if (tip == 20)
            {
                foreach (Person person in list)
                {
                    if (person.GetTip() == "admin")
                    {
                        persons.Add(person);
                    }
                }
                return persons;
            }
            if (tip == 30)
            {
                foreach (Person person in list)
                {
                    if (person.GetTip() == "manager")
                    {
                        persons.Add(person);
                    }
                }
                return persons;
            }
            if (tip == 40)
            {
                foreach (Person person in list)
                {
                    if (person.GetTip() == "student")
                    {
                        persons.Add(person);
                    }
                }
                return persons;
            }
            if (tip == 50)
            {
                foreach (Person person in list)
                {
                    if (person.GetTip() == "teacher" || person.GetTip() == "admin" || person.GetTip() == "manager")
                    {
                        persons.Add(person);
                    }
                }
                return persons;
            }
            if (tip == 60)
            {
                Console.WriteLine("\nВводите дипазон." +
                                  "\nОт - ");
                int ot = int.Parse(Console.ReadLine());
                Console.WriteLine("\nДо - ");
                int doy = int.Parse(Console.ReadLine());
                foreach (Person person in list)
                {
                    if (person.vozrast <= doy && person.vozrast>=ot)
                    {
                        persons.Add(person);
                    }
                }
                return persons;
            }
            tip = 4;
            return persons;
        }
    }
}
