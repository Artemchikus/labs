﻿using System;
using System.Collections.Generic;

namespace Uprazhnenie_1
{
    public class Book : Item, Ipr
    {
        public string Autor { get; set; }
        public string Title { get; set; }
        public Publisher Publ { get; set; }
        public int Pages { get; set; }
        public int Year { get; set; }
        public bool returnSrok { get; private set; }

        private static double price;

        public static double Price
        {
            get { return price; }
            set
            {
                if (value > 9)
                {
                    price = value;
                }
            }
        }

        public void setBook(string Autor, string Title, Publisher publisher, int Pages, int Year)
        {
            this.Autor = Autor;
            this.Pages = Pages;
            this.Publ = publisher;
            this.Title = Title;
            this.Year = Year;
        }

        public void SetPrice(double price)
        {
            Book.Price = price;
        }

        public override string ToString()
        {
            string bs = String.Format(
                "\nКнига: \nАвтор: {0}\nНазвание: {1}\nГод издания: {2}\n{3} стр.\nСтоимость аренды: {4} \nИздательство{5}", Autor, Title,
                Year, Pages, Price, Publ);
            return bs;
        }

        public override void Print()
        {
            Console.WriteLine(this);
            base.Print();
        }

        public double PriceBook(int s)
        {
            double cust = s * price;
            return cust;
        }

        public Book(string Autor, string Title, Publisher publisher, int Pages, int Year)
        {
            this.Autor = Autor;
            this.Pages = Pages;
            this.Publ = publisher;
            this.Title = Title;
            this.Year = Year;
        }
        public Book() { }

        static Book()
        {
            price = 9;
        }

        public Book(string Autor, string Title)
        {
            this.Autor = Autor;
            this.Title = Title;
        }
        public Book(string Autor, string Title, Publisher publisher, int Pages, int Year, long invNumber, bool taken) : base(invNumber, taken)
        {
            this.Autor = Autor;
            this.Pages = Pages;
            this.Publ = publisher;
            this.Title = Title;
            this.Year = Year;
        }

        public void ReturnSrok()
        {
            returnSrok = true;
        }

        public override void Return()
        {
            if (returnSrok == true)
            {
                taken = true;
            }
            else
            {
                taken = false;
            }
        }
    }
}
