﻿using System;
using System.Collections.Generic;
using Uprazhnenie_1;

namespace MyclassTest
{
    public class Program
    {
        static void Main(string[] args)
        {
            Publisher publ = new Publisher(1234, new DateTime(2014, 12, 14), "Наука и жизнь", "nauka@mail.ru");

            Book b2 = new Book("Толстой Л.Н.", "Война и Мир", publ, 1234, 2013, 101, true);

            b2.TakeItem();
            b2.Print();

            Book b3 = new Book("Лермонтов М.Ю", "Мцыри");

            b3.Print();

            Audit.RunAudit();
            Magazine mag1 = new Magazine("О природе", 5, "Земля и мы", 2014, 1235, true);
            mag1.TakeItem();
            mag1.Print();
            mag1.Subs();
            mag1.Print();

            Magazine mag2 = new Magazine("Volume", 12, "Title", 2001, 11245, true);
            mag2.TakeItem();
            mag2.Print();
            Audit.StopAudit();
            mag2.Subs();
            mag2.Print();

            Console.WriteLine("\nТестирование полиморфизма");
            b2.ReturnSrok();
            Item it;
            it = b2;
            it.TakeItem();
            it.Return();
            it.Print();

            it = mag1;
            it.TakeItem();
            it.Return();
            it.Print();

            List<Item> itlList = new List<Item>();
            itlList.AddRange(new Item[] {b2, b3, mag1});
            itlList.Sort();
            Console.WriteLine("\n Сортировка по тнвертароному номеру");
            foreach (Item x in itlList)
            {
                x.Print();
            }
        }
    }
}