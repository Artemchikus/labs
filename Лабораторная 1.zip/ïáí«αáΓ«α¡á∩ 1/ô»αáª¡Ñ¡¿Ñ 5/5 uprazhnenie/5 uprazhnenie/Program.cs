﻿using System;

namespace _5_uprazhnenie
{
    class Plosad_treugolnika
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Vvedite perimetr treugolnika");
                string i = Console.ReadLine();
                double p = Double.Parse(i);
                double a = p / 3;
                p = p / 2;
                double s = Math.Sqrt(p * Math.Pow(p - a, 3));
                Console.WriteLine("Ploshad=" + s);
            }
            catch (FormatException e)
            {
                Console.WriteLine(e);
            }
        }
    }
}
