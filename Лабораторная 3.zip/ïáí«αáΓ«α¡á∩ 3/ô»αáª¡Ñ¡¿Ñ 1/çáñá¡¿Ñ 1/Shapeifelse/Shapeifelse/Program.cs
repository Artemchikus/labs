﻿using System;

namespace Shapeifelse
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("x=");
            float x = float.Parse(Console.ReadLine());
            Console.Write("y=");
            float y = float.Parse(Console.ReadLine());
            if (x * x + y * y < 9 && y > 0)
            {
                Console.Write("Vnutri");
            }
            else if (x * x + y * y > 9 || y < 0)
            {
                Console.Write("Vne");
            }
            else
            {
                Console.Write("Na granice");
            }

        }
    }
}
