﻿using System;

namespace _3_zadanie
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vvedite nomer goda");
            int god = Int32.Parse(Console.ReadLine());
            if (god % 4 == 0 && god % 100 != 0)
            {
                Console.WriteLine("Yes");
            }
            else if ((god % 400 == 0))
            {
                Console.WriteLine("Yes");
            }
            else
            {
                Console.WriteLine("No");
            }
        }
    }
}
