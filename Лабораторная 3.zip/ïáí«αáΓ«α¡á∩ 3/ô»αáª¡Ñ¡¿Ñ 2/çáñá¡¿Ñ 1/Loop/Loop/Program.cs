﻿using System;

namespace Loop
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("n=");
            int n = int.Parse(Console.ReadLine());
            Console.Write("\nwhile: \t\t");
            int i = 1;
            while (i <= n)
            {
                Console.Write(" " + i);
                i += 2;
            }

            Console.Write("\ndo while: \t");
            i = 1;
            do
            {
                Console.Write(" " + i);
                i += 2;
            } while (i <= n);

            Console.Write("\nfor: \t\t");
            for (i = 1; i <= n; i += 2)
            {
                Console.Write(" " + i);
            }

            double x, x1, x2, y;
            Console.Write("\nx1=");
            x1 = double.Parse(Console.ReadLine());
            Console.Write("x2=");
            x2 = double.Parse(Console.ReadLine());
            Console.Write("\nx\t sin(x)\t");
            x = x1;
            do
            {
                y = Math.Sin(x);
                Console.Write("\n{0} \t{1}", x, y);
                x = x + 0.01;
            } while (x <= x2);

            Console.Write("\nx\t sin(x)\t");
            x = x1;
            while (x <= x2)
            {
                y = Math.Sin(x);
                Console.Write("\n{0} \t{1}", x, y);
                x = x + 0.01;
            }

            int a, b, temp, a1, b1;
            Console.Write("\na=");
            a = int.Parse(Console.ReadLine());
            Console.Write("b=");
            b = int.Parse(Console.ReadLine());
            temp = a;
            a1 = a;
            b1 = b;
            while (temp != b)
            {
                a = temp;
                if (a < b)
                {
                    temp = a;
                    a = b;
                    b = temp;
                }

                temp = a - b;
                a = b;
            }
            Console.WriteLine("Nod=" + a);

            temp = a1;
            do
            {
                a1 = temp;
                if (a1 < b1)
                {
                    temp = a1;
                    a1 = b1;
                    b1 = temp;
                }
                temp = a1 - b1;
                a1 = b1;
            } while (temp != b1);
            Console.WriteLine("Nod="+a1);
        }
    }
}
