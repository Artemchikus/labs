﻿using System;

namespace Zadanie_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Vvedie vash nomer v spiske:");
            int nomer = int.Parse(Console.ReadLine());
            Console.Write("Vvedie kol-vo vistrelov:");
            int n = int.Parse(Console.ReadLine());
            int [,]vistrly=new int [n,2];
            double s;
            int x=0, y=0, summ=0;
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Vveite coordinatu x");
                vistrly[i, 0] = int.Parse(Console.ReadLine());
                Console.WriteLine("Vvefie coordinatu y");
                vistrly[i, 1] = int.Parse(Console.ReadLine());
            }
            Random rnd=new Random();
            int centrx = rnd.Next(-3, 3);
            int centry = rnd.Next(-3, 3);
            for (int i = 0; i < n; i++)
            {
                x = rnd.Next(-1, 1);
                y = rnd.Next(-1, 1);
                Console.WriteLine("Pomeha = "+x+" "+y);
                s = Math.Sqrt((vistrly[i, 0] + x - centrx) * (vistrly[i, 0] + x - centrx) 
                              + (vistrly[i, 1] + y - centry) * (vistrly[i, 1] + y - centry));
                if (s <= 1)
                {
                    summ += 10;
                }
                else if (s<=2)
                {
                    summ += 5;
                }
                else if (nomer%2==0 && s<=3)
                {
                    summ += 1;
                }
            }
            Console.WriteLine("Summa ochkov = "+summ);
            Console.WriteLine("Center bil v: "+x+" "+y);
        }
    }
}
