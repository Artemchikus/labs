﻿using System;

namespace _2_Zadanie
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("k=");
            int k = int.Parse(Console.ReadLine());
            Console.WriteLine("m=");
            int m = int.Parse(Console.ReadLine());
            int s=0;
            for (int i = 1; i <= 100; i++)
            {
                if (i > k && i < m) 
                    continue; 
                s += i;
            }
            Console.WriteLine("Summa="+s);
        }
    }
}
