﻿using System;

namespace MyClass
{
    class Book
    {
        public string Autor { get; set; }
        public string Title { get; set; }
        public string Publisher { get; set; }
        public int Pages { get; set; }
        public int Year { get; set; }

        private static double price = 9;
        
        public static double Price
        {
            get { return price; }
            set {
                if (value > 9)
                {
                    price = value;
                }
            }
        }

        public void setBook(string Autor, string Title, string Publisher, int Pages, int Year)
        {
            this.Autor = Autor;
            this.Pages = Pages;
            this.Publisher = Publisher;
            this.Title = Title;
            this.Year = Year;
        }

        public static void setPrice(double price)
        {
            Book.Price = price;
        }

        public override string ToString()
        {
            string bs = String.Format(
                "\nКнига: \nАвтор: {0}\nНазвание: {1}\nГод издания: {2}\n{3} стр.\nСтоимость аренды: {4}", Autor, Title,
                Year, Pages, Price);
            return bs;
        }

        public void Print()
        {
            Console.WriteLine(this);
        }

        public double PriceBook(int s)
        {
            double cust = s * price;
            return cust;
        }
            static void Main(string[] args)
        {
            Book b1=new Book();

            b1.setBook("Пушкин А.С.", "Капитанская дочка", "Вильямс", 123, 2018);
            
            Book.setPrice(5);
            
            b1.Print();
            
            Console.WriteLine("\nИтоговая стоимость аренды: {0} р.",b1.PriceBook(3));
        }
    }
}
