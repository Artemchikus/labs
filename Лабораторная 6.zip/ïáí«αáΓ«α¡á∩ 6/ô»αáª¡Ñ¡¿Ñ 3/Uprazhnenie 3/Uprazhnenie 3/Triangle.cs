﻿using System;

namespace Uprazhnenie_3
{
    class Triangle
    {
        public double storona1;
        public double storona2;
        public double storona3;

        public Triangle(double storona1, double storona2, double storona3)
        {
            if (storona1<storona2+storona3 && storona2<storona1+storona3 && storona3<storona1+storona2)
            {
                this.storona1 = storona1;
                this.storona2 = storona2;
                this.storona3 = storona3;
            }
            else
            {
                Console.WriteLine("Ошибочка вышла, такого треугольника не существует");
            }
        }

        public void Print()
        {
            Console.WriteLine("Сторона 1 = {0}, Сторона 2 = {1}, Сторона 3 = {2}",storona1,storona2,storona3);
        }

        public double Perimetr()
        {
            return storona2 + storona1 + storona3;
        }

        public double Ploshad()
        {
            double p = Perimetr() / 2;
            return Math.Sqrt(p * (p - storona1) * (p - storona2) * (p - storona3));
        }
        static void Main(string[] args)
        {
            double[]mas=new double[3];
            
            for (int i = 0; i < 3; i++)
            {
                Console.Write("Длина стороны {0} = ",i+1);
                mas[i] = double.Parse(Console.ReadLine());
            }

            Triangle t1=new Triangle(mas[0],mas[1],mas[2]);
            
            t1.Print();
            Console.WriteLine("Периметр = " + t1.Perimetr());
            Console.WriteLine("Площадь = " + t1.Ploshad());
        }
    }
}
