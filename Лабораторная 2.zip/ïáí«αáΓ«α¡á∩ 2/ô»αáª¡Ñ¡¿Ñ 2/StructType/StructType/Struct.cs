﻿using System;

namespace StructType
{
    class Struct
    {
        public enum AccountType { Checking, Deposit}
        public struct BankAccount
        {
            public long accNo=1;
            public decimal accBal;
            public AccountType accType;
        }
        static void Main(string[] args)
        {
            BankAccount goldAccount;
            goldAccount.accType = AccountType.Checking;
            goldAccount.accBal = (decimal) 3200.00;
            Console.WriteLine("Enter account number:");
            goldAccount.accNo = long.Parse(Console.ReadLine());
            Console.WriteLine("*** Account Summary ***");
            Console.WriteLine("Acc Number {0}",goldAccount.accNo);
            Console.WriteLine("Acc Type {0}",goldAccount.accType);
            Console.WriteLine("Acc Balance ${0}", goldAccount.accBal);
        }
    }
}
