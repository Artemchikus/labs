﻿using System;

namespace _3_Uprazhnenie
{
    class Program
    {
        struct Distance
        {
            public int feet;
            public int inch;
        }
        static void Main(string[] args)
        {
            Distance distance1;
            Distance distance2;
            Distance distance3;
            Console.WriteLine("Vvedie futy");
            distance1.feet = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Vvedite duymi");
            distance1.inch = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Vvedie futy");
            distance2.feet = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Vvedite duymi");
            distance2.inch = Int32.Parse(Console.ReadLine());
            distance3.inch = distance1.inch + distance2.inch;
            distance3.feet = distance1.feet + distance2.feet;
            distance3.feet += (int) (distance3.inch / 12);
            distance3.inch = distance3.inch % 12;
            Console.WriteLine("Distance 1 = {0} '- {1}\"",distance1.feet,distance1.inch);
            Console.WriteLine("Distance 2 = {0} '- {1}\"", distance2.feet, distance2.inch);
            Console.WriteLine("Distance 3 = {0} '- {1}\"", distance3.feet, distance3.inch);
        }
    }
}
